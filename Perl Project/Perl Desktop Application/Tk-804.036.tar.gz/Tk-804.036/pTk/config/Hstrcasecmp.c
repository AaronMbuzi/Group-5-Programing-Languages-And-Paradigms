#include <string.h>

int main()
{
 return strcasecmp("", "");
}

